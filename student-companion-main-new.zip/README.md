# Student Companion - Gen Z Study Buddy 🚀

A futuristic, Gen Z-friendly web app with glassmorphism UI for students. Features mood tracking, AI chatbot, travel planning, internship search, event management, and academic tracking.

## 🎯 Features

- **Authentication**: Firebase email/password auth
- **Mood Companion**: Track mental wellness with questionnaires
- **AI Chatbot**: Career guidance, skill learning, exam prep, nearby places
- **Travel Planner**: Book flights, hotels, and UPI payments
- **Internships**: Browse opportunities on Internshala
- **Events**: Create and manage campus events
- **Academics**: Track marks and assignments

## 🛠️ Tech Stack

- **Framework**: Next.js 14 (App Router)
- **Language**: TypeScript
- **Styling**: Tailwind CSS (Glassmorphism)
- **Auth & DB**: Firebase Authentication + Firestore
- **APIs**: YouTube Data API v3, Google Places API
- **Deployment**: Vercel

## 📦 Installation

### 1. Clone and Install Dependencies

```bash
cd D:\student-companion
npm install
```

### 2. Configure Firebase

1. Go to [Firebase Console](https://console.firebase.google.com/)
2. Create a new project
3. Enable Authentication (Email/Password)
4. Create Firestore Database
5. Copy your Firebase config

Create `.env.local` file:

```env
NEXT_PUBLIC_FIREBASE_API_KEY=your_api_key
NEXT_PUBLIC_FIREBASE_AUTH_DOMAIN=your_project.firebaseapp.com
NEXT_PUBLIC_FIREBASE_PROJECT_ID=your_project_id
NEXT_PUBLIC_FIREBASE_STORAGE_BUCKET=your_project.appspot.com
NEXT_PUBLIC_FIREBASE_MESSAGING_SENDER_ID=your_sender_id
NEXT_PUBLIC_FIREBASE_APP_ID=your_app_id
```

### 3. Configure API Keys

Add to `.env.local`:

```env
# YouTube Data API v3
YOUTUBE_API_KEY=your_youtube_api_key

# Google Places API
GOOGLE_PLACES_API_KEY=your_places_api_key

# LLM API (Optional - for future)
LLM_API_KEY=your_llm_api_key
```

**Get API Keys:**
- YouTube: [Google Cloud Console](https://console.cloud.google.com/) → Enable YouTube Data API v3
- Places: Same console → Enable Places API
- LLM: OpenAI, Anthropic, etc. (optional)

### 4. Run Development Server

```bash
npm run dev
```

Open [http://localhost:3000](http://localhost:3000)

## 🚀 Deployment to Vercel

### Method 1: GitHub Integration (Recommended)

1. Push code to GitHub:
```bash
git init
git add .
git commit -m "Initial commit"
git remote add origin your-repo-url
git push -u origin main
```

2. Go to [Vercel Dashboard](https://vercel.com/dashboard)
3. Click "New Project"
4. Import your GitHub repository
5. Configure environment variables in Vercel:
   - Add all variables from `.env.local`
   - Go to Settings → Environment Variables
6. Deploy!

### Method 2: Vercel CLI

```bash
npm install -g vercel
vercel login
vercel
```

Follow prompts and add environment variables when asked.

## 📁 Project Structure

```
student-companion/
├── app/
│   ├── layout.tsx              # Root layout
│   ├── page.tsx                # Home/redirect
│   ├── login/page.tsx          # Login page
│   ├── register/page.tsx       # Register page
│   ├── dashboard/page.tsx      # Dashboard
│   ├── companion/page.tsx      # Mood + Chatbot
│   ├── travel/page.tsx         # Travel planner
│   ├── internships/page.tsx    # Internships
│   ├── events/page.tsx         # Events
│   ├── academics/page.tsx      # Marks + Assignments
│   └── api/
│       ├── llm/route.ts        # LLM API endpoint
│       ├── youtube/route.ts    # YouTube proxy
│       └── places/route.ts     # Places proxy
├── components/
│   ├── Navbar.tsx              # Navigation bar
│   ├── MoodQuestionnaire.tsx   # Mood tracking
│   ├── Chatbot.tsx             # AI chatbot
│   └── ui/
│       ├── GlassCard.tsx       # Glassmorphism card
│       └── PrimaryButton.tsx   # Styled button
├── context/
│   └── AuthContext.tsx         # Firebase auth context
├── lib/
│   ├── firebase.ts             # Firebase config
│   ├── llm.ts                  # LLM helper
│   ├── youtube.ts              # YouTube helper
│   └── places.ts               # Places helper
├── styles/
│   └── globals.css             # Global styles
├── package.json
├── tsconfig.json
├── tailwind.config.ts
└── vercel.json
```

## 🎨 Design System

### Glassmorphism Theme
- **Background**: Dark gradient (navy → purple)
- **Cards**: Semi-transparent with backdrop blur
- **Colors**: Neon purple, cyan, pink accents
- **Typography**: Inter font family
- **Borders**: Rounded (20-30px) with subtle glow

### Components
- `GlassCard`: Reusable glass panel
- `PrimaryButton`: Gradient button with hover effects
- `Navbar`: Glassmorphic navigation bar

## 🔧 Configuration

### Firestore Collections

```
users/
  - uid, name, email, createdAt

moodEntries/
  - uid, timestamp, answers, moodScore, moodLabel

marks/
  - uid, subjectName, internalMarks, externalMarks, total, semester

assignments/
  - uid, subject, title, dueDate, status, notes

events/
  - title, description, location, dateTime, createdBy, isCollegeEvent
```

### Environment Variables

All environment variables should be set in:
- Local: `.env.local`
- Vercel: Dashboard → Settings → Environment Variables

## 📝 TODO / Future Enhancements

- [ ] Real LLM integration (OpenAI/Anthropic)
- [ ] Real geolocation for Places API
- [ ] User role management for admin features
- [ ] Assignment file uploads
- [ ] Calendar view for events
- [ ] Push notifications
- [ ] Dark/light theme toggle
- [ ] Mobile app (React Native)

## 🐛 Troubleshooting

### Firebase Errors
- Ensure all Firebase config variables are set
- Check Firebase console for enabled services
- Verify Firestore security rules

### API Errors
- Verify API keys are correct
- Check API quotas in Google Cloud Console
- Ensure APIs are enabled

### Build Errors
- Run `npm install` to ensure all dependencies
- Clear `.next` folder: `rm -rf .next`
- Check TypeScript errors: `npm run lint`

## 📄 License

MIT License - Free to use and modify

## 🤝 Contributing

1. Fork the repository
2. Create feature branch: `git checkout -b feature-name`
3. Commit changes: `git commit -m 'Add feature'`
4. Push to branch: `git push origin feature-name`
5. Submit pull request

## 📧 Support

For issues or questions, open a GitHub issue or contact the maintainer.

---

Built with ❤️ for students by students
